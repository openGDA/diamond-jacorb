/***** Copyright (c) 1999 Object Management Group. Unlimited rights to 
       duplicate and use this code are hereby granted provided that this 
       copyright notice is included.
*****/

package org.omg.CORBA_2_3.portable;

public abstract class Delegate extends org.omg.CORBA.portable.Delegate {

    public java.lang.String get_codebase(org.omg.CORBA.Object self) {
        return null;
    }
}
