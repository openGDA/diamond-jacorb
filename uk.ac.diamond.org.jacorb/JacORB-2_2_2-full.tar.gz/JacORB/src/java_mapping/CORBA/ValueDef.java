/***** Copyright (c) 1999 Object Management Group. Unlimited rights to 
       duplicate and use this code are hereby granted provided that this 
       copyright notice is included.
*****/

package org.omg.CORBA;

public interface ValueDef extends org.omg.CORBA.ValueDefOperations,
                org.omg.CORBA.Container, org.omg.CORBA.Contained,
                org.omg.CORBA.IDLType, org.omg.CORBA.portable.IDLEntity {

}
