package org.omg.CORBA;

/** 
 * CORBA V2.3 - 1.3 July 1998 (merged version)
 *
 * @deprecated Deprecated by CORBA 2.2
 *
 * last modified: 02/03/99 RT
 */
public class Principal {
   
	/** 
	 * @deprecated Deprecated by CORBA 2.2
	 */
	public byte[] name() {
		throw new org.omg.CORBA.NO_IMPLEMENT();
	}

	/** 
	 * @deprecated Deprecated by CORBA 2.2
	 */
	public void name(byte[] name) {
		throw new org.omg.CORBA.NO_IMPLEMENT();
	}
} 



