package org.omg.CORBA;

public interface AliasDef extends org.omg.CORBA.AliasDefOperations,
                org.omg.CORBA.TypedefDef, org.omg.CORBA.portable.IDLEntity {

}
