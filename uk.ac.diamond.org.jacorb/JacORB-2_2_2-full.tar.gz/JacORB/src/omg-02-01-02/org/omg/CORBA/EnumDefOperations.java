/***** Copyright (c) 1999 Object Management Group. Unlimited rights to 
       duplicate and use this code are hereby granted provided that this 
       copyright notice is included.
*****/

package org.omg.CORBA;

public interface EnumDefOperations extends org.omg.CORBA.TypedefDefOperations {

    public java.lang.String[] members ();
    public void members(java.lang.String[] members);

}
