/***** Copyright (c) 1999 Object Management Group. Unlimited rights to 
       duplicate and use this code are hereby granted provided that this 
       copyright notice is included.
*****/

package org.omg.CORBA;

public interface NativeDef extends org.omg.CORBA.NativeDefOperations,
            org.omg.CORBA.TypedefDef, org.omg.CORBA.portable.IDLEntity {

}
