package org.omg.CORBA;

public interface AliasDefOperations extends org.omg.CORBA.TypedefDefOperations{

    public org.omg.CORBA.IDLType original_type_def();
    public void original_type_def(org.omg.CORBA.IDLType original_type_def);

}
