/***** Copyright (c) 2001 Object Management Group. Unlimited rights to 
       duplicate and use this code are hereby granted provided that this 
       copyright notice is included.
*****/

package org.omg.CORBA;

public interface LocalInterface extends org.omg.CORBA.Object {
}
